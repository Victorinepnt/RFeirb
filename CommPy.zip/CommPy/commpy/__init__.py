"""
CommPy
================================================


Contents
--------

Subpackages
-----------
::

 channelcoding                --- Channel Coding Algorithms [*]

"""
#from channelcoding import *
from CommPy.commpy.filters import *
from CommPy.commpy.modulation import *
from CommPy.commpy.impairments import *
from CommPy.commpy.sequences import *
from CommPy.commpy.channels import *

try:
    from numpy.testing import Tester
    test = Tester().test
except:
    pass
