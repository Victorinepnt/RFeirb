.. automodule:: commpy.modulation
    :members:
