.. automodule:: commpy.channels
