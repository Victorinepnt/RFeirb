.. automodule:: commpy.sequences
