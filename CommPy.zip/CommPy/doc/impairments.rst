.. automodule:: commpy.impairments
